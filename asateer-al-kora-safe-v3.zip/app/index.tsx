import { View, StyleSheet } from 'react-native';

export default function Index() {
  return <View style={styles.container} />;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0A0A' },
});
